a=[x for x in range (1000) if not x%3 or not x%5]
sum=0
for y in a:
    sum=sum+y
print (a)
print (sum)

