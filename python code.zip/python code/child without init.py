class BaseClass(object):
    def __init__(self,water):
        print("Base")
        self.test_water=water
    def get_water1(self,bottle):
        print("getting hot {0} in {1}".format(self.test_water,bottle))
class TestFn(BaseClass):
    def get_water(self,bottle):
        self.bottle=bottle
        #super(TestFn,self).get_water('Mybottle')
        print("Getting cold {0} from my class in {1}".format(self.test_water,bottle))
  
         
    def display_name(self):
        print(self.test_water)
   

first_class=TestFn("water")



#print(first_class.test_water)
first_class.get_water('officebottle')
first_class.get_water1('bot')

