def isloggedin(func):
    def check():
        login =True
        print("checking")
        if login == True:
            func()
        else:
            print("login failed")
    return check

@isloggedin
def ordinary():
    print ("i am ordinary")
@isloggedin
def show_profile():
    print("Myprofile")

ordinary()
show_profile()
