list=123
print(list)

