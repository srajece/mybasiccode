char="test"
for i in char:
    print(i)



sample=[]
for i in char:
    sample.append(i)


list(char)

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
                
child_age=10
dict(age=child_age,name="test")

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

email="test@gmail.com"
email.index("@")

\\\\\\\\\\\\\\\\\\\\\\\(to find th lngth)\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
contr=0
for i in email:
    contr=contr+1
print (contr)

\\\\\\\\\\\\\\\\\\\\\\\\\(o find lenght before @)\\\\\\\\\\\\\\\\\\\\\\\\\

countr =0
for i in email:
    if i=="@":
        print(counter)
        countr=countr+1
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\(if two same lettr/////////////

sample="tstingteam"
first=sample.index("t")
slicing_value=first+1
sliced_char=sampl[slicing_value:]
print sliced char.index('t')+slicing_value
\\\\\\\\\\\\\\\\\\\\\\\\\to count char\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


a=askdaksifrngfnwpdsakdls
a count("a")


\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
                                                            


            
