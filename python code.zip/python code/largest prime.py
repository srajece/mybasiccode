data=600851475143
x=[]
y=2
while data/y!=0:
    
    if (data %y==0):
       
        x=i
        y=data/i
        print(x)
        print(y)
        
    
