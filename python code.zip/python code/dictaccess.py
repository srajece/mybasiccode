dic={'name':'python', 'address':{'street':'test','city':'chennai','state':'TN'}}
b=['address','state']
for key in b:
    dic=dic[key]
print(dic)
    
