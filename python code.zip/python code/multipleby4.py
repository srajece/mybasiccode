a=0
opt=[i for i in range(101) if(i%4==0)]
a=opt+a
print(a)
