from collections import Counter
list1={1:2,2:4}
cnt=Counter(list1)
print((cnt.elements()))
