test = 'sampling'
print (test[1:-1:1])

