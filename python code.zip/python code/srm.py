cust={'a':'aa','b':"bb"}
cust['birth']= 123
print(cust)
