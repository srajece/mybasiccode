totalmark=0
a=list(input())
for i in a:
    totalmark=totalmark+i

averagemark=totalmark/len(a)
print(averagemark)


split
