sample_odd=[i for i in range(101) if i%2!=0]
sample_even=[i for i in range(101) if i%2==0]
print(sample_odd)
print(sample_even)
